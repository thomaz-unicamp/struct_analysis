# -*- coding: utf-8 -*-
"""
Created on Sat Jun 19 09:54:51 2021

2D Truss algorithm

@author: Thomaz Buttignol
University of Campinas
all rights reserved
"""
#Units; SI (m. kPa, kN)

import numpy as np

#import data
loads = np.loadtxt('loads.txt', usecols=range(1)) #nodes coordinates
bc = np.loadtxt('bc.txt', usecols=range(1)) #nodes coordinates
coord = np.loadtxt('coord.txt', usecols=range(3)) #nodes coordinates
stiff = np.loadtxt('stiff.txt', usecols=range(1)) #EA/L
f = open('le_coord.txt', 'r')
text_file = open("le_coord.txt", "r")
lec = text_file.readlines()
text_file.close()
l1=np.zeros((len(stiff),3))
l2=np.zeros((len(stiff),3))
var=0
for i in range(len(stiff)):
    var=i*2
    l1[i]=lec[var].split(",") #beam local coordinate 1
    l2[i]=lec[var+1].split(",") #beam local coordinate 2
le=np.zeros(len(stiff)) #beams length
for i in range(len(stiff)):
    le[i] = np.sqrt((l2[i,0]-l1[i,0])**2+(l2[i,1]-l1[i,1])**2++(l2[i,2]-l1[i,2])**2)
cm = np.loadtxt('connect.txt', usecols=range(len(le))) #connectivity matrix
cm=np.transpose(cm)

#mount global stiffness matrix (KK)
KK=np.zeros((3*len(coord),3*len(coord))) #global stiffness matrix
l=np.zeros(len(le)) 
m=np.zeros(len(le))
n=np.zeros(len(le))
#global stiffness matrix
for j in range(len(le)):
    l=(l2[j,0]-l1[j,0])/le[j]
    m=((l2[j,1]-l1[j,1])/le[j])
    n=((l2[j,2]-l1[j,2])/le[j])
    u=int(3*cm[j,0])
    v=int(3*cm[j,1])
    #global stiffness matrix
    KK[u,u]=KK[u,u]+l**2*stiff[j]
    KK[u,u+1]=KK[u+1,u]=KK[u,u+1]+l*m*stiff[j] 
    KK[u,u+2]=KK[u+2,u]=KK[u,u+2]+l*n*stiff[j]     
    KK[u,v]=KK[v,u]=KK[u,v]-l**2*stiff[j]
    KK[u,v+1]=KK[v+1,u]=KK[u,v+1]-l*m*stiff[j]
    KK[u,v+2]=KK[v+2,u]=KK[u,v+2]-l*n*stiff[j]    
    KK[u+1,u+1]=KK[u+1,u+1]+ m**2*stiff[j]
    KK[u+1,u+2]=KK[u+2,u+1]=KK[u+1,u+2]+ m*n*stiff[j]    
    KK[u+1,v]= KK[v,u+1]=KK[u+1,v]-l*m*stiff[j]
    KK[u+1,v+1]=KK[v+1,u+1]=KK[u+1,v+1]-m**2*stiff[j]
    KK[u+1,v+2]=KK[v+2,u+1]=KK[u+1,v+2]-m*n*stiff[j] 
    KK[u+2,u+2]=KK[u+2,u+2]+ n**2*stiff[j] 
    KK[u+2,v]=KK[v,u+2]=KK[u+2,v]-l*n*stiff[j] 
    KK[u+2,v+1]=KK[v+1,u+2]=KK[u+2,v+1]-m*n*stiff[j] 
    KK[u+2,v+2]=KK[v+2,u+2]=KK[u+2,v+2]-n**2*stiff[j]    
    KK[v,v]=KK[v,v]+l**2*stiff[j]
    KK[v,v+1]=KK[v+1,v]=KK[v,v+1]+l*m*stiff[j]    
    KK[v,v+2]=KK[v+2,v]=KK[v,v+2]+l*n*stiff[j]     
    KK[v+1,v+1]=KK[v+1,v+1]+m**2*stiff[j]
    KK[v+1,v+2]=KK[v+2,v+1]=KK[v+1,v+2]+m*n*stiff[j]   
    KK[v+2,v+2]=KK[v+2,v+2]+n**2*stiff[j]    
print("det.KK=",np.linalg.det(KK))

#compute the nodal displacements
bc1=np.where(bc == 0)
bc1=bc1[0]
loads1=loads
KK1=KK
for i in range(len(bc1)):
    KK1=np.delete(KK1, int(bc1[i]), 0)
    KK1=np.delete(KK1, int(bc1[i]), 1)
    loads1=np.delete(loads1, int(bc1[i]), 0)
    for j in range(len(bc1)-1):
        if bc1[j]<bc1[j+1]: bc1[j+1]=bc1[j+1]-1     
#solve system of linear equations 
####################print("compare=",np.linalg.solve(KK1, loads1))#############
#solve system of equations using Gaussian elimination
A=KK1
b=loads1
#front elimination
n=len(b)
for k in range(n-1):
    for i in range(k+1,n):
        c=A[i][k]/A[k][k]
        for j in range(k+1,n):
            A[i][j]=A[i][j]-c*A[k][j]
            A[i][k]=0
        b[i]=b[i]-c*b[k]
#back substitution
for u in range(n):
    i=n-1-u
    sum=0
    for j in range(i+1,n):
        sum=sum+A[i][j]*b[j]
    b[i]=(b[i]-sum)/A[i][i]

#nodal displacements [m]
displ=np.zeros(len(bc))
j=0
for i in range(len(bc)):
    if bc[i]==1: 
        displ[i]=b[j] #nodal displacements
        j=int(j+bc[i])
print("displ",displ)
#internal forces [kN]
ff=np.zeros(len(le))
for j in range(len(le)):
    l=(l2[j,0]-l1[j,0])/le[j]
    m=((l2[j,1]-l1[j,1])/le[j])  
    u=int(2*cm[j,0])
    v=int(2*cm[j,1])
    ff[j]=np.sum(stiff[j]*np.array([-l,-m, l, m])*np.transpose([displ[u],displ[u+1],displ[v],displ[v+1]])) #internal forces
print("ff=",ff)
#reactions [kN]
KK2=KK
j=0
for i in range(len(bc)):
    if bc[i]==1:       
        KK2=np.delete(KK2, j, 0)
        j=j-1
    j=j+1
RV=np.zeros(len(KK2)) #reaction values
for i in range(len(KK2)):
    RV[i]=np.sum(KK2[i,:]*np.transpose(displ))
print("RV=",RV)
